# Complex Tableau TDE Migration Test Package

This synthetic package is designed to test TABLEAU2PBI. It includes workbook metadata, data-source metadata, Prep flow metadata, local sources, SQL, a legacy .tde placeholder, a Hyper placeholder, TDE lineage metadata, visual definitions, parameters, LOD calculations, table calculations, RAWSQL and external model-extension examples.

Expected behavior: the app must detect the TDE, recover upstream source logic from TWB/TDS/TFL and tde.meta.json, ignore TDE as production source, and use original files/connection metadata for Power BI source mapping.
