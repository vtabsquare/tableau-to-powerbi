SELECT o.OrderID, o.OrderDate, o.ShipDate, o.CustomerID, o.ProductID, o.Sales, o.Profit, o.Quantity, c.Region, c.State
FROM dbo.FactSales o
LEFT JOIN dbo.DimCustomer c ON o.CustomerID = c.CustomerID
WHERE o.OrderDate >= ''2025-01-01'';