# Complex Tableau Retail Migration Test Package

Use this ZIP to test the TABLEAU2PBI Enterprise Migration Workbench.

## Recommended test
Upload `complex_tableau_retail_migration_test.zip` to the application.

## What this package contains
- Tableau workbook XML: `00_Complex_Retail_Operations_Migration_Test.twb`
- Tableau packaged workbook: `packaged/Complex_Retail_Operations_Migration_Test.twbx`
- Tableau data source: `datasources/Reusable_Retail_Federated_Source.tds`
- Tableau packaged data source: `packaged/Reusable_Retail_Federated_Source.tdsx`
- Tableau Prep flow XML: `prep/Customer_Order_Enrichment_Flow.tfl`
- CSV sources: orders, customers, products, returns
- Excel source: monthly sales targets
- JSON source: discount policy
- XML source: territory mapping
- Placeholder `.hyper` and `.tde` extracts for inventory/manual-review behavior
- Custom SQL file for pass-through SQL review
- Expected migration findings JSON and source mapping template

## Migration behavior this should test
1. Full inventory of mixed Tableau and source files.
2. Workbook summary: dashboards, worksheets, story, datasources, connections, calculations, parameters and filters.
3. Source mapping and 10-row previews for CSV/Excel/JSON/XML.
4. Relationship designer candidates using Customer ID, Product ID, Order ID, Region and Month.
5. Calculation conversion:
   - Easy row-level calculations: Order Profit, Product Margin.
   - DAX measures: Total Sales, Profit Ratio, Distinct Customers.
   - LOD conversion/manual validation: Region Sales LOD.
   - Manual review: RUNNING_SUM, RANK_DENSE, WINDOW_SUM, RAWSQL_REAL, MODEL_EXTENSION_BOOL.
6. Visual conversion plan:
   - Bar, line, text table, heat map, scatter, map, top-N, dual-axis and unsupported analytics dashboard.
7. Safe-openable principle:
   Unsupported Tableau behavior should be preserved in migration report and validation, not blindly exported as invalid Power BI logic.

## Notes
The `.twb`, `.tds`, and `.tfl` files are XML-based synthetic Tableau-style artifacts for parser/migration testing. They are intentionally designed to stress the migration workbench, not to be a pixel-perfect Tableau Desktop business report.
