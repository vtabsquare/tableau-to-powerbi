-- Tableau Custom SQL used by the Complex Retail workbook
-- Purpose: customer lifetime value and return-risk scoring.
SELECT
    o.customer_id,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(o.sales) AS lifetime_sales,
    SUM(o.sales - o.cost) AS lifetime_profit,
    SUM(CASE WHEN r.return_flag = 'Yes' THEN 1 ELSE 0 END) AS return_count
FROM mart.fact_orders o
LEFT JOIN mart.fact_returns r
    ON o.order_id = r.order_id
WHERE o.order_date >= DATE '2025-01-01'
GROUP BY o.customer_id;
